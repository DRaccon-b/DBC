# Karte 02 (Factorial Town) – v1.1

Regeln aus `CLAUDE.md` angewendet; v1.0 in `maps/karte02/v1.0/`.

- **Regel 1/1b – Raster:** alle Objekte im kleinsten Kachelblock, waagerecht zentriert, Fuß bündig.
- **Verdeckung durch Gebäude:** Hallen, Dächer, Fassaden, Reaktorhalle und Außenmauern schneiden Objekte daneben ab
  (Objekte davor/auf dem Dach bleiben sichtbar; Förderbänder und Rohre zählen nicht als Wand).
- **Reaktor-Pods:** die unteren Pods stehen bündig unter den oberen, keiner berührt die Wand.
- **Keine Überlappungen:** nach dem Einrasten überlappende Kleinobjekte entfernt.
- Nicht angewendet, weil auf dieser Karte nicht vorhanden bzw. nicht passend: Wege in Bögen (Industriestraßen
  bleiben gerade), Plateaus/Klippen (Seitenkanten), Bäume, Wasserfälle.

Neu bauen: `python3 tools/karte02_objekte.py && python3 tools/regeln_v11.py karte02 && python3 tools/karte02_bauen.py && python3 tools/karte02_animation.py`

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte02_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
