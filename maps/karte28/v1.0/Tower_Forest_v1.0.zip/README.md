# Karte 28 – Tower Forest (A02) v1.0

100 × 85 Kacheln à 16 px (1600 × 1360), Vorlage `assets/vorlagen/karte28_vorlage.png`. Spielt in einem dunklen Wald.

## Inhalt der Karte
- **Dunkler Wald ringsum**: Gras-, Weg- und Erdkacheln von Karte 01 (GBA-Stil), dunkler und kühler gefärbt;
  dunkle Waldbäume (umgefärbt aus Karte 01, `tools/karte28_baeume.py`).
- **Schlamm-Arena** links als Erhöhung: nasse Walderde mit Rissen und Erdflecken, Grasrand mit sichtbarer
  Plateaukante im Norden und an den Seiten, Steinfront mit zwei Steintreppen im Süden. Wurzeln, Totholz,
  Findlinge, Stämme, Pilze, Pfützen, Spinnweben in den oberen Ecken.
- **Spinnen-Arena** rechts auf dem Steinplatz: unregelmäßige Ringmauer am 16er-Raster (2 Kacheln dick, Fronten,
  Torlücke unten), Spinnweben hängen an Mauerkrone und Fronten; dunkle Kristallbrocken, umgestürzter Turm am Weg.
- **12 schwarze Obelisken** (Türme) nach der Vorlage, ohne Leuchten.
- **Wiesen** mit Feldwegen, einzelnen Bäumen mit Begleitern (Regel 5d), kleinen Nadelbäumen, Lagerfeuer mit
  Sitzstämmen, Wegweiser, Laterne, Pilzen und Büscheln.
- **Ausgänge** (Teleporter) oben rechts und unten in der Mitte.

## Animation (4 Bilder, 250 ms)
Bäume, Gräser und Blumen im Wind, Lagerfeuer, Laterne, Teleporter. Steine, Mauern, Obelisken und Kristalle sind
unbewegt.

## Dateien
- `Tower_Forest_v1.0.png` – Standbild, `Tower_Forest_v1.0_discord.gif` – Animation für Discord (2×).
- `kollision/` – Kollisionsraster (`kollision.json`, `.txt`, `ebene2_kollision.png`, `kollision_overlay.png`):
  blockiert sind Wald, Mauer der Spinnen-Arena, Arena-Front und Plateaukanten sowie die Füße der Objekte;
  die zwei Treppen führen in die Schlamm-Arena.

Erzeugt mit `tools/karte28_layout.py`, `karte28_bauen.py`, `karte28_baeume.py`, `karte28_objekte.py`,
`karte28_animation.py`, `kollision.py karte28`, `tileset_export.py karte28`. Neue Objekte: PixelLab
Objekt-Creator (`k28_*`).

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte28_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
