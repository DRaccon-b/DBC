# Karte 20 – Startdorf (A02) v1.0

60 × 48 Kacheln à 16 px (960 × 768), Vorlage `assets/vorlagen/karte20_vorlage.png`.
Startkarte von Gebiet A02, im Stil von Karte 06 (Primary Village).

## Inhalt der Karte
- **Wald ringsum** (Bäume von Karte 01); oben rechts ragen die Waldbäume über die Plateaukante.
- **Fluss**: kommt oben aus dem Wald, läuft nach Süden und links aus der Karte (vertiefter Wasserstil wie der Teich
  von Karte 06); an den zwei Holzbrücken genau so breit wie die Brücken.
- **Fernseher** mit Steintreppe – exakt derselbe wie auf Karte 06 (Portalbild dreht sich).
- **Vier Strohdachhäuser** mit Kaminrauch.
- **Dorfplatz** aus Kopfstein: Brunnen auf dem Rasen in der Mitte, Laternen, Bänke und Marktstände paarweise
  symmetrisch, Fässer, Säcke, Anschlagbrett, rosa Kirschbäume.
- **Beetgarten** (geschlossener Zaun): Möhren, Kohl und Weizen gleichmäßig in den Beeten, Vogelscheuche.
- **Feld** unten links (geschlossener Zaun) mit Vogelscheuchen und Heuballen.
- **Windmühle** mit drehenden Gitterflügeln, Heuballen, Schubkarre, Holzstapel.
- **Plateau** oben rechts mit Felsfront, Steintreppe, Bänken und Wegweiser.
- **Ausgänge** mit Teleportern unten in der Mitte und rechts.

## Animation (4 Bilder, 250 ms – Regel: höchstens 4 Animationsbilder)
Windmühlenflügel (22,5° je Bild, Schatten dreht mit), Kaminrauch, Fluss, Fernseher-Portal, Laternen, Teleporter,
Kirschbäume, Weizen und Gräser im Wind.

## Dateien
- `Startdorf_v1.0.png` – Standbild (960 × 768), `Startdorf_v1.0_discord.gif` – Animation für Discord (2×, 1920 × 1536).
- `kollision/` – Kollisionsraster (`kollision.json`, `.txt`, `ebene2_kollision.png`, `kollision_overlay.png`):
  Dorf und Plateau (über die Treppe) sind eine zusammenhängende begehbare Fläche, Brücken begehbar; blockiert sind
  Wald, Fluss, Felsfront, Zäune und die Füße der Objekte.

Erzeugt mit `tools/karte20_layout.py`, `karte20_bauen.py`, `karte20_objekte.py`, `karte20_animation.py`,
`kollision.py karte20`, `tileset_export.py karte20`. Neue Objekte: PixelLab Objekt-Creator (`k20_*`).

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte20_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
