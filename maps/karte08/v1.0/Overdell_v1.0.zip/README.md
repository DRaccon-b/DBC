# Karte 08 – Overdell – v1.0

100 × 90 Kacheln à 16 px, Vorlage `assets/vorlagen/karte08_vorlage.png`.

```
python3 tools/karte08_layout.py      # Raster + Hoehenstufen aus der Vorlage -> layout.json
python3 tools/karte08_kacheln.py     # Bodenkacheln (Karte-01-Gras/Sand duester umgefaerbt)
python3 tools/karte08_bauen.py       # Gelaende (pixelhoehe.npy fuer die Objektpruefung)
python3 tools/karte08_objekte.py && python3 tools/regeln_v11.py karte08 && python3 tools/karte08_objekte.py symmetrie && python3 tools/karte08_bauen.py
python3 tools/karte08_animation.py   # animation/ (webp, Discord-GIF, Detail-GIFs)
```

- Ringsum schwarzer Fels (Ebene 7) mit Geroell und Felsbrocken, schwarze Felsnasen und ein Felsloch links.
- Terrassenberg in der Mitte: 4 Terrassen + Schlossplateau, Treppen abwechselnd links/rechts (Ebenen 2–6).
- Dunkles gotisches Schloss oben mittig (Devimons Sitz), Gargoyles, Banner, Saeulen, Geisterlaternen.
- Friedhof links (tote Baeume) und unten: Mausoleum, Gruften, Grabreihen, Lagerplatz mit Bannern unten links,
  Sumpf (vertieft, zwei Tiefenstufen) mit verwitterter Holzbruecke, rechter Friedhof auf dem Berg.
- Krypten, Mausoleum und Kapelle als Haeuser mit Dach; Eisentor geteilt, je ein Fluegel an jeder Treppe.
- Schwarzer Fels mit Geroellfeldern, Moos, Rissen, Felsnadeln und violett glimmenden Kristallen (Auswahl 0,1,4,6,7,8,
  9,10,11,14,15), auch oben links, am linken Rand und unten.
- Schlossplatz: Gargoyles, Banner, Laternen, Saeulen exakt spiegelsymmetrisch zur Schlossachse.
- Einbettung: kleine Begleiter (Gras, Buesche, Pilze, Unkraut) vor den Ecken groesserer Objekte.
- Objekte: PixelLab (`assets/objekte/karte08/`), alle am 16×16-Raster, Schatten nur auf der eigenen Ebene,
  Verdeckung durch Hoehen, keine Ueberlappungen (Pixelpruefung, 2 px Abstand), keine Grabsteine auf Wegen.

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte08_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
