<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects" tilewidth="118" tileheight="113" tilecount="51" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <properties>
   <property name="sprite" value="decor_00_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_00_grass.png" width="30" height="23"/>
 </tile>
 <tile id="1">
  <properties>
   <property name="sprite" value="decor_01_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_01_grass.png" width="26" height="22"/>
 </tile>
 <tile id="2">
  <properties>
   <property name="sprite" value="decor_03_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_03_grass.png" width="26" height="24"/>
 </tile>
 <tile id="3">
  <properties>
   <property name="sprite" value="decor_05_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_05_grass.png" width="28" height="29"/>
 </tile>
 <tile id="4">
  <properties>
   <property name="sprite" value="decor_06_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_06_grass.png" width="26" height="18"/>
 </tile>
 <tile id="5">
  <properties>
   <property name="sprite" value="decor_08_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_08_grass.png" width="23" height="19"/>
 </tile>
 <tile id="6">
  <properties>
   <property name="sprite" value="decor_09_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_09_grass.png" width="32" height="28"/>
 </tile>
 <tile id="7">
  <properties>
   <property name="sprite" value="decor_09_sand"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_09_sand.png" width="32" height="28"/>
 </tile>
 <tile id="8">
  <properties>
   <property name="sprite" value="decor_10_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_10_grass.png" width="26" height="22"/>
 </tile>
 <tile id="9">
  <properties>
   <property name="sprite" value="decor_14_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_14_grass.png" width="26" height="23"/>
 </tile>
 <tile id="10">
  <properties>
   <property name="sprite" value="decor_26_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_26_grass.png" width="32" height="30"/>
 </tile>
 <tile id="11">
  <properties>
   <property name="sprite" value="decor_27_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_27_grass.png" width="32" height="27"/>
 </tile>
 <tile id="12">
  <properties>
   <property name="sprite" value="decor_27_sand"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_27_sand.png" width="32" height="27"/>
 </tile>
 <tile id="13">
  <properties>
   <property name="sprite" value="decor_31_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_31_grass.png" width="22" height="25"/>
 </tile>
 <tile id="14">
  <properties>
   <property name="sprite" value="decor_33_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_33_grass.png" width="26" height="30"/>
 </tile>
 <tile id="15">
  <properties>
   <property name="sprite" value="decor_38_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_38_grass.png" width="27" height="27"/>
 </tile>
 <tile id="16">
  <properties>
   <property name="sprite" value="decor_61_grass"/>
   <property name="group" value="decor"/>
  </properties>
  <image source="sprites/decor_61_grass.png" width="32" height="29"/>
 </tile>
 <tile id="17">
  <properties>
   <property name="sprite" value="jungle_00_grass"/>
   <property name="group" value="jungle"/>
  </properties>
  <image source="sprites/jungle_00_grass.png" width="118" height="113"/>
 </tile>
 <tile id="18">
  <properties>
   <property name="sprite" value="large_00_grass"/>
   <property name="group" value="large"/>
  </properties>
  <image source="sprites/large_00_grass.png" width="66" height="65"/>
 </tile>
 <tile id="19">
  <properties>
   <property name="sprite" value="large_01_grass"/>
   <property name="group" value="large"/>
  </properties>
  <image source="sprites/large_01_grass.png" width="64" height="61"/>
 </tile>
 <tile id="20">
  <properties>
   <property name="sprite" value="large_09_grass"/>
   <property name="group" value="large"/>
  </properties>
  <image source="sprites/large_09_grass.png" width="53" height="49"/>
 </tile>
 <tile id="21">
  <properties>
   <property name="sprite" value="large_13_grass"/>
   <property name="group" value="large"/>
  </properties>
  <image source="sprites/large_13_grass.png" width="36" height="63"/>
 </tile>
 <tile id="22">
  <properties>
   <property name="sprite" value="large_14_grass"/>
   <property name="group" value="large"/>
  </properties>
  <image source="sprites/large_14_grass.png" width="63" height="51"/>
 </tile>
 <tile id="23">
  <properties>
   <property name="sprite" value="portal_01_grass"/>
   <property name="group" value="portal"/>
  </properties>
  <image source="sprites/portal_01_grass.png" width="60" height="58"/>
 </tile>
 <tile id="24">
  <properties>
   <property name="sprite" value="trees_00_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_00_grass.png" width="48" height="46"/>
 </tile>
 <tile id="25">
  <properties>
   <property name="sprite" value="trees_00_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_00_grass_m.png" width="48" height="46"/>
 </tile>
 <tile id="26">
  <properties>
   <property name="sprite" value="trees_01_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_01_grass.png" width="48" height="46"/>
 </tile>
 <tile id="27">
  <properties>
   <property name="sprite" value="trees_01_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_01_grass_m.png" width="48" height="46"/>
 </tile>
 <tile id="28">
  <properties>
   <property name="sprite" value="trees_02_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_02_grass.png" width="44" height="44"/>
 </tile>
 <tile id="29">
  <properties>
   <property name="sprite" value="trees_02_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_02_grass_m.png" width="44" height="44"/>
 </tile>
 <tile id="30">
  <properties>
   <property name="sprite" value="trees_03_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_03_grass.png" width="30" height="30"/>
 </tile>
 <tile id="31">
  <properties>
   <property name="sprite" value="trees_03_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_03_grass_m.png" width="30" height="30"/>
 </tile>
 <tile id="32">
  <properties>
   <property name="sprite" value="trees_04_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_04_grass.png" width="44" height="46"/>
 </tile>
 <tile id="33">
  <properties>
   <property name="sprite" value="trees_04_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_04_grass_m.png" width="44" height="46"/>
 </tile>
 <tile id="34">
  <properties>
   <property name="sprite" value="trees_05_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_05_grass.png" width="46" height="46"/>
 </tile>
 <tile id="35">
  <properties>
   <property name="sprite" value="trees_05_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_05_grass_m.png" width="46" height="46"/>
 </tile>
 <tile id="36">
  <properties>
   <property name="sprite" value="trees_06_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_06_grass.png" width="38" height="47"/>
 </tile>
 <tile id="37">
  <properties>
   <property name="sprite" value="trees_06_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_06_grass_m.png" width="38" height="47"/>
 </tile>
 <tile id="38">
  <properties>
   <property name="sprite" value="trees_07_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_07_grass.png" width="30" height="44"/>
 </tile>
 <tile id="39">
  <properties>
   <property name="sprite" value="trees_07_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_07_grass_m.png" width="30" height="44"/>
 </tile>
 <tile id="40">
  <properties>
   <property name="sprite" value="trees_08_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_08_grass.png" width="26" height="37"/>
 </tile>
 <tile id="41">
  <properties>
   <property name="sprite" value="trees_08_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_08_grass_m.png" width="26" height="37"/>
 </tile>
 <tile id="42">
  <properties>
   <property name="sprite" value="trees_09_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_09_grass.png" width="42" height="47"/>
 </tile>
 <tile id="43">
  <properties>
   <property name="sprite" value="trees_09_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_09_grass_m.png" width="42" height="47"/>
 </tile>
 <tile id="44">
  <properties>
   <property name="sprite" value="trees_12_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_12_grass.png" width="46" height="39"/>
 </tile>
 <tile id="45">
  <properties>
   <property name="sprite" value="trees_12_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_12_grass_m.png" width="46" height="39"/>
 </tile>
 <tile id="46">
  <properties>
   <property name="sprite" value="trees_13_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_13_grass.png" width="42" height="37"/>
 </tile>
 <tile id="47">
  <properties>
   <property name="sprite" value="trees_13_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_13_grass_m.png" width="42" height="37"/>
 </tile>
 <tile id="48">
  <properties>
   <property name="sprite" value="trees_14_grass"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_14_grass.png" width="46" height="34"/>
 </tile>
 <tile id="49">
  <properties>
   <property name="sprite" value="trees_14_grass_m"/>
   <property name="group" value="trees"/>
  </properties>
  <image source="sprites/trees_14_grass_m.png" width="46" height="34"/>
 </tile>
 <tile id="50">
  <properties>
   <property name="sprite" value="well_00_grass"/>
   <property name="group" value="well"/>
  </properties>
  <image source="sprites/well_00_grass.png" width="45" height="48"/>
 </tile>
</tileset>
