<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="objects" tilewidth="82" tileheight="83" tilecount="33" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <properties>
   <property name="sprite" value="computer_00"/>
   <property name="group" value="computer"/>
  </properties>
  <image source="sprites/computer_00.png" width="60" height="61"/>
 </tile>
 <tile id="1">
  <properties>
   <property name="sprite" value="computer_08"/>
   <property name="group" value="computer"/>
  </properties>
  <image source="sprites/computer_08.png" width="28" height="62"/>
 </tile>
 <tile id="2">
  <properties>
   <property name="sprite" value="computer_15"/>
   <property name="group" value="computer"/>
  </properties>
  <image source="sprites/computer_15.png" width="32" height="62"/>
 </tile>
 <tile id="3">
  <properties>
   <property name="sprite" value="gate_07"/>
   <property name="group" value="gate"/>
  </properties>
  <image source="sprites/gate_07.png" width="40" height="62"/>
 </tile>
 <tile id="4">
  <properties>
   <property name="sprite" value="gate_08"/>
   <property name="group" value="gate"/>
  </properties>
  <image source="sprites/gate_08.png" width="36" height="62"/>
 </tile>
 <tile id="5">
  <properties>
   <property name="sprite" value="gate_09"/>
   <property name="group" value="gate"/>
  </properties>
  <image source="sprites/gate_09.png" width="63" height="62"/>
 </tile>
 <tile id="6">
  <properties>
   <property name="sprite" value="gate_10"/>
   <property name="group" value="gate"/>
  </properties>
  <image source="sprites/gate_10.png" width="62" height="47"/>
 </tile>
 <tile id="7">
  <properties>
   <property name="sprite" value="net_01"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_01.png" width="28" height="43"/>
 </tile>
 <tile id="8">
  <properties>
   <property name="sprite" value="net_02"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_02.png" width="10" height="42"/>
 </tile>
 <tile id="9">
  <properties>
   <property name="sprite" value="net_03"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_03.png" width="21" height="44"/>
 </tile>
 <tile id="10">
  <properties>
   <property name="sprite" value="net_04"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_04.png" width="27" height="41"/>
 </tile>
 <tile id="11">
  <properties>
   <property name="sprite" value="net_07"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_07.png" width="29" height="39"/>
 </tile>
 <tile id="12">
  <properties>
   <property name="sprite" value="net_09"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_09.png" width="32" height="35"/>
 </tile>
 <tile id="13">
  <properties>
   <property name="sprite" value="net_14"/>
   <property name="group" value="net"/>
  </properties>
  <image source="sprites/net_14.png" width="40" height="39"/>
 </tile>
 <tile id="14">
  <properties>
   <property name="sprite" value="small_00"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_00.png" width="20" height="13"/>
 </tile>
 <tile id="15">
  <properties>
   <property name="sprite" value="small_04"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_04.png" width="18" height="16"/>
 </tile>
 <tile id="16">
  <properties>
   <property name="sprite" value="small_05"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_05.png" width="24" height="24"/>
 </tile>
 <tile id="17">
  <properties>
   <property name="sprite" value="small_08"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_08.png" width="12" height="22"/>
 </tile>
 <tile id="18">
  <properties>
   <property name="sprite" value="small_10"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_10.png" width="30" height="20"/>
 </tile>
 <tile id="19">
  <properties>
   <property name="sprite" value="small_11"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_11.png" width="25" height="22"/>
 </tile>
 <tile id="20">
  <properties>
   <property name="sprite" value="small_13"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_13.png" width="26" height="27"/>
 </tile>
 <tile id="21">
  <properties>
   <property name="sprite" value="small_17"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_17.png" width="16" height="30"/>
 </tile>
 <tile id="22">
  <properties>
   <property name="sprite" value="small_19"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_19.png" width="28" height="29"/>
 </tile>
 <tile id="23">
  <properties>
   <property name="sprite" value="small_22"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_22.png" width="17" height="30"/>
 </tile>
 <tile id="24">
  <properties>
   <property name="sprite" value="small_27"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_27.png" width="22" height="22"/>
 </tile>
 <tile id="25">
  <properties>
   <property name="sprite" value="small_31"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_31.png" width="27" height="29"/>
 </tile>
 <tile id="26">
  <properties>
   <property name="sprite" value="small_33"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_33.png" width="28" height="28"/>
 </tile>
 <tile id="27">
  <properties>
   <property name="sprite" value="small_35"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_35.png" width="26" height="26"/>
 </tile>
 <tile id="28">
  <properties>
   <property name="sprite" value="small_38"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_38.png" width="16" height="26"/>
 </tile>
 <tile id="29">
  <properties>
   <property name="sprite" value="small_53"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_53.png" width="22" height="25"/>
 </tile>
 <tile id="30">
  <properties>
   <property name="sprite" value="small_56"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_56.png" width="28" height="29"/>
 </tile>
 <tile id="31">
  <properties>
   <property name="sprite" value="small_58"/>
   <property name="group" value="small"/>
  </properties>
  <image source="sprites/small_58.png" width="24" height="25"/>
 </tile>
 <tile id="32">
  <properties>
   <property name="sprite" value="virus_01"/>
   <property name="group" value="virus"/>
  </properties>
  <image source="sprites/virus_01.png" width="82" height="83"/>
 </tile>
</tileset>
