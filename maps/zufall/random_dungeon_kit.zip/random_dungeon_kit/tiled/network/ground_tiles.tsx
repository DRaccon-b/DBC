<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ground" tilewidth="16" tileheight="16" tilecount="2327" columns="64">
 <image source="ground_tiles.png" width="1024" height="592"/>
</tileset>
