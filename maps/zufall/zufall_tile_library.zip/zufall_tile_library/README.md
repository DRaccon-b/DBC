# Zufalls-Dungeon – Kartenstück-Bibliothek (Stil Karte 01)

Vorgefertigte Kartenstücke (16×16-px-Kacheln, 14×14 Kacheln je Stück), aus denen beim Betreten eines Dungeons
eine zufällige Karte zusammengesetzt wird – Prinzip wie bei Path of Exile.

```
zufall_tile_library/
├── js/                         fertig zum Einbauen
│   ├── zufall_dungeon.js       ES-Modul: Seed → Grundriss → Stücke → Ebenen + Kollision
│   ├── demo.html               Testseite (Ladebildschirm, Figur, Kollision, Kamera)
│   ├── manifest.json           145 Lagen: Kanten, Kollision, Spawn/Boss, Gewichte, Bildpfade
│   └── stuecke/                je Lage 3 PNGs
│       ├── <lage>_boden.png    Boden mit Schatten (224×224, Arena 448×448)
│       ├── <lage>_objekte.png  Bäume/Deko/Portal … (+4 Kacheln Rand für überstehende Kronen)
│       └── <lage>_oben.png     obere Objektteile – über der Spielfigur zeichnen
├── definition/
│   ├── stuecke.json            die 20 Stücke als Raster (F Wald, G Wiese, P Weg, W Teich), Kanten, Objekte
│   └── stuecke_uebersicht.png  dieselben Raster als Bild (rot = feste Objekte)
└── vorschau/
    ├── bibliothek_alle_lagen.png   alle 145 Lagen gerendert
    ├── system_explained.png        Erklärgrafik (englisch)
    └── vorschau_demo_42.png / vorschau_spiel_7.png
```

## Lagen-Namen

`<stück>_<lage>`: `0`, `90`, `180`, `270` = im Uhrzeigersinn gedreht, `s…` = vorher waagerecht gespiegelt.
Beispiel: `weg_ecke_s90` = Wegecke, gespiegelt und um 90° gedreht.

## Kanten

Jede Seite eines Felds hat einen Typ (Schlüssel `"fx,fy,Seite"`, Seite N/O/S/W = Nord/Ost/Süd/West):

| Typ | äußere zwei Kachelreihen | Bedeutung |
|---|---|---|
| `Z` | `FFFFFFFFFFFFFF` | zu (Wald) |
| `W` | `FFFFGGPPGGFFFF` | schmaler Waldweg |
| `O` | `FFGGGGPPGGGGFF` | offene Wiese mit Weg |

Zwei Stücke passen nebeneinander, wenn die sich berührenden Kanten denselben Typ haben.

## Benutzen

```bash
cd js && python3 -m http.server 8000      # dann http://localhost:8000/demo.html
```

```js
import { erzeugeDungeon, ladeBilder, zeichneDungeon } from './zufall_dungeon.js';
const manifest = await (await fetch('manifest.json')).json();
const dungeon = erzeugeDungeon(manifest, seed, { breite: 6, hoehe: 5 });
const { unten, oben } = zeichneDungeon(manifest, dungeon, await ladeBilder(manifest, dungeon, './'));
// zeichnen: unten → Figuren → oben;  dungeon.istFrei(x, y), dungeon.spawn, dungeon.boss
```

Kollision im Manifest: je Lage 14 Zeichenketten aus `0` (begehbar) und `1` (Wald, Wasser, Objekt-Sockel).

Quelle und Neu-Export: Repository DBC, `tools/zufall_stuecke.py` (Stücke), `tools/zufall_export.py`
(Rendern), `tools/zufall_karte.py` (Python-Generator).
