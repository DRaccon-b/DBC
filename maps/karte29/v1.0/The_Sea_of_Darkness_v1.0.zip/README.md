# Karte 29 – The Sea of Darkness (A02) v1.0

90 × 80 Kacheln à 16 px (1440 × 1280), Vorlage `assets/vorlagen/karte29_vorlage.png`. Alles am 16×16-Raster.

## Inhalt der Karte
- **Meer im Stil von Karte 01** (terrassiert), schwarzgrau: flaches Wasser mit sichtbarem Sandgrund, zwei tiefere
  Stufen mit Stufenwänden, Unterwasserfelsen, Algen, Schaumkante und Brandung; Stufen genau am Raster.
- **Strand** graublau mit hellen Sandflecken und Pfützen, **10 Felsblöcke** mit Schieferfront (3 im Meer).
- **Spawnplatz** oben links: rundlicher Pflasterplatz mit dem Portal von Holy Peaks (schwarz-grau-weiß) und vier Laternen (symmetrisch).
- **Leuchtturm** oben rechts mit dunkler Felsnadel im Meer daneben, lange dunkle Steinbrücke hinunter zum **Tempel**: Tempeltor auf der Brückenachse,
  Statue eines Meeresgottes, drei Säulenpaare spiegelsymmetrisch, Säulenstümpfe, Treppe im Süden direkt ins Wasser.
- **Strand-Objekte:** großes Schiffswrack, Ruderboote, Bootswrack, Anker, Felsbrocken, Muscheln, Treibholz, Gräten, Seetang.
- **Portale:** Portal wie Karte 07 (Spawn), Wasserstrudel unten rechts.

## Animation (4 Bilder, 250 ms)
Meer (Lichtstriche, Schaum, Brandung, Algen), Leuchtturmlicht, Laternen, Portal und Strudel, Seetang.
Steine, Felsen, Säulen, Statue und Brücken sind unbewegt.

## Dateien
- `The_Sea_of_Darkness_v1.0.png` – Standbild, `The_Sea_of_Darkness_v1.0_discord.gif` – Animation für Discord (2×).
- `kollision/` – Kollisionsraster: blockiert sind Meer, Felsfronten, Tempelfront und Objektfüße; Treppe und Brücken begehbar.

Erzeugt mit `tools/karte29_layout.py`, `karte29_bauen.py`, `karte29_objekte.py`, `karte29_animation.py`,
`kollision.py karte29`, `tileset_export.py karte29`. Neue Objekte: PixelLab Objekt-Creator (`k29_*`),
wiederverwendet aus Karte 11 und 25.

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte29_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
