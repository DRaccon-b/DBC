# Karte 09 – Vamdemon's Keep – v1.0

90 × 86 Kacheln à 16 px, Vorlage `assets/vorlagen/karte09_vorlage.png`.

```
python3 tools/karte09_layout.py && python3 tools/karte09_kacheln.py && python3 tools/karte09_bauen.py
python3 tools/karte09_objekte.py && python3 tools/regeln_v11.py karte09 && python3 tools/karte09_objekte.py symmetrie
python3 tools/karte09_bauen.py
python3 tools/karte09_animation.py
```

- Schloss oben: Portalhalle, grosser Saal (roter Teppich als Kreuz), Ritualsaal mit Orgel, Altar, Saergen und
  violettem Teppichrahmen, zwei Gaerten; Mauern mit 3 Kacheln hoher Wandflaeche, Buntglasfenstern, Bannern, Bildern.
- Aussenmauer mit Tuermen, Haupttor, Burggraben mit Zugbruecke.
- Friedhof unten: Wege, dunkle Teiche mit Bruecke und Steg, Felsplateaus, Gruften und Kapellen (aus Overdell),
  Steinkreis, Lagerplatz, Teleporter links.
- Portal mit acht Kristallen in den acht Farben (Orange, Blau, Rot, Lila, Gruen, Grau, Gelb, Rosa); Wirbel dreht sich.
- Tore (PixelLab) mit offenem Durchgang, mittig auf dem Teppich; Wachtuerme in gleichen Abstaenden, Banner dazwischen.
- Raeume: Portalhalle, Bibliothek mit Kamin, Thron, Speisesaal, Ritualsaal; alle Paare symmetrisch zur Saalachse.
- Animation: Sumpfwasser, Flammen (Fackeln, Kerzen, Kamin, Feuerschalen), Portal, Geisterlicht, Glimmen, Gras im Wind.
- Objekte: PixelLab neu (`assets/objekte/karte09/{gross,moebel,tor,wand}`), wiederverwendet aus Karte 08 (`k8/`).

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte09_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
