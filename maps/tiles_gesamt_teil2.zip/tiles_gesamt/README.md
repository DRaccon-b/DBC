# Alle Tiles (16 x 16) - 32 Karten

Alle Kacheln und Objekte aus den Tilesets der Karten in einem Ordner, am 16x16-Raster. Gleiche Kacheln (Pixel fuer
Pixel) liegen nur einmal vor; `index.json` sagt fuer jede Kachel und jedes Objekt, aus welchen Karten es stammt.

| Ordner/Datei | Inhalt |
|---|---|
| `boden/statisch.png` | 55365 unbewegte Bodenkacheln, 64 je Zeile |
| `boden/karte01_ueberlagerung.png` | 2716 Ueberlagerungs-Kacheln von Karte 01 (liegen ueber dem Spieler) |
| `boden/animiert_4bilder.png` + `_frames/` | 20711 animierte Bodenkacheln, 4 Bilder (Bild 0-3 untereinander, gleicher Platz) |
| `boden/animiert_16bilder.png` + `_frames/` | 8785 animierte Bodenkacheln, 16 Bilder (aeltere Karten) |
| `objekte/statisch.png` | 1373 Objekte, jedes in seinem eigenen Kachelblock (Breite/Hoehe in index.json) |
| `objekte/animiert_4bilder.png` + `_frames/` | 413 animierte Objekte, 4 Bilder |
| `objekte/animiert_16bilder.png` + `_frames/` | 353 animierte Objekte, 16 Bilder |
| `objekte/karte01/` | 63 Objekt-Sprites von Karte 01 einzeln |
| `index.json` | Position (x, y in Kacheln), Groesse, Animation und Herkunft jeder Kachel / jedes Objekts |
| `vorschau.png` | verkleinerte Uebersicht |

Animierte Blaetter: alle Bilder einer Animation liegen untereinander; Bild b einer Kachel steht bei
y + b x (Bildhoehe), x gleich. Laufzeit: 4 Bilder 250 ms, 16 Bilder 110-170 ms je Bild.

Aufteilung (je unter 50 MB): `tiles_gesamt_teil1.zip` enthaelt alle Blaetter (Boden statisch, Ueberlagerung, Boden
4 und 16 Bilder als Gesamtblatt, Objekte statisch und 4 Bilder) samt Einzelbildern der 4-Bilder-Animationen;
`tiles_gesamt_teil2.zip` enthaelt die Einzelbilder der 16-Bilder-Bodenanimation und die animierten Objekte mit 16
Bildern. Beide ZIPs in denselben Ordner entpacken - sie ergaenzen sich zu `tiles_gesamt/`.

Karten:
- karte01 - Wald und Strand
- karte02 - Factorial Town
- karte03 - Server Desert
- karte04 - Gear Savanna
- karte05 - Freezeland
- karte06 - Startkarte
- karte07 - The Holy Peaks
- karte08 - Overdell
- karte09 - Vamdemon's Keep
- karte10 - Toy Town
- karte11 - Spiral Mountain: Dark Ocean
- karte12 - Spiral Mountain: Puppet Woods
- karte13 - Spiral Mountain: Machine City
- karte14 - Spiral Mountain: Summit
- karte15 - Apocalymon's Realm
- karte16 - The Network
- karte17 - Our War Game!
- karte18 - The Fog-Bound City
- karte19 - Revenge
- karte20 - Startdorf
- karte21 - Digi-Egg Valley
- karte23 - Harvest Hills
- karte24 - The Kaiser's Canyon
- karte25 - Sunset Bay
- karte26 - The Kaiser's Fortress
- karte27 - Destiny Lake
- karte28 - Tower Forest
- karte29 - The Sea of Darkness
- karte30 - Odaiba
- karte31 - Highton View Terrace
- karte32 - Dream Ruins
- karte33 - The World of Dreams

Erzeugt mit `tools/tiles_gesamt.py` aus `maps/karteNN/tileset/`.
