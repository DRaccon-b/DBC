# Karte 11 – Spiral Mountain: Dark Ocean v1.0

80 × 70 Kacheln à 16 px (1280 × 1120), Vorlage `assets/vorlagen/karte11_vorlage.png`.
Links schwarzes, verseuchtes Land, rechts das Meer der Finsternis – erste Karte der Spiral-Mountain-Reihe.

## Inhalt der Karte
- **Rand:** Bergwand ringsum (dieselbe wie Puppet Woods, Machine City und Summit), Teleporter oben und links.
- **Land:** schwarze Asche, ölige Tümpel, zwei lila Plateaus mit Treppen und toten Bäumen, Felsblock, Ruinen-Platz
  mit Feuerschalen, Walskelett, gestrandetes Wrack, Anker, Mastbruch, Treibholz, Kristalle, Knochen.
- **Meer:** türkises Flachwasser mit Seetangfeldern, Korallen, Anemone, Kristall; Tiefsee in fünf Stufen bis zum
  Kartenrand im öligen Schwarz-Violett, Felsnadeln (kleiner, je tiefer das Wasser), versunkenes Wrack.
- **Bannkreis-Plattform:** Achteck, dessen Mauer bis zum Meeresgrund reicht, Bannkreis mit Spirale, Runensäulen
  und Feuerschalen spiegelgleich; Steinbrücke mit Bögen und Pfeilern bis zum Grund, Brückenkopf mit Laternen.

## Animation (16 Bilder, 170 ms)
Flachwasser (Lichtnetz), Tiefsee (Wellenkämme), Schaum am Ufer, Seetang im Wind, Tümpel (Ölhaut), Feuerschalen,
Geisterlaternen, Runensäulen und Kristalle (Glimmen), Bannkreis (Spirale dreht sich), Teleporter.

## Dateien
- `Spiral_Mountain_Dark_Ocean_v1.0.png` – Standbild, `Spiral_Mountain_Dark_Ocean_v1.0_discord.gif` – Animation.
- `kollision/` – Kollisionsraster (`kollision.json`, `.txt`, `ebene2_kollision.png`, `kollision_overlay.png`).

Erzeugt mit `tools/karte11_layout.py`, `karte11_kacheln.py`, `karte11_bauen.py`, `karte11_objekte.py`,
`regeln_v11.py karte11`, `karte11_animation.py`, `kollision.py karte11`, `tileset_export.py karte11`.

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte11_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
