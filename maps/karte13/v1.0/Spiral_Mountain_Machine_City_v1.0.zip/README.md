# Karte 13 – Spiral Mountain: Machine City v1.0

80 × 70 Kacheln à 16 px (1280 × 1120), Vorlage `assets/vorlagen/karte13_vorlage.png`.
Zerstörte Maschinenstadt am Spiral Mountain. Anspielungen auf den Herrn der Stadt nur über Stil und Farben.

## Inhalt der Karte
- **Rand:** dieselbe Bergwand wie Dark Ocean, Puppet Woods und Summit; Schrottrand vom Kartenrand angeschnitten,
  versunkene Maschinenteile (Zahnrad, Panzerkette, Roboterarm, Mech-Kopf), Kabel und Rohre über die Kuppe,
  Warnleuchten, Funkmasten, Kamera, Zäune, Stacheldraht, Warnschilder, Kristalladern und Ölflecken.
  Festungstor, Panzertüren und Teleporter bleiben frei.
- **Maschinenfestung:** eine Etage höher, Metallboden, Front mit Warnstreifen und roten Leuchten, Metalltreppe,
  Festungstor mit rotem Auge, Panzertüren, Reaktoren und Konsolen spiegelgleich, Boss-Kreis im Maschinenstil.
- **Höfe:** Industriehof (Lagerhalle, Fabrik, Schornsteine, Ofen, Strommast, Generator) und Hof mit Funkturm, Tanks,
  Rohren; Giftwasser-Becken auf Laborboden mit Warnstreifen-Rand.
- **Stadt:** Straßenraster mit Bordsteinen, Mittellinie und Zebrastreifen, Häuserblöcke mit sichtbaren Dächern
  (Wohnblöcke, Ladenzeilen, Büros, Glastürme), Kran-, Bus- und Autowracks, Drachen-Wrack (eigenes Objekt
  „dragondead“), Laternen, Ampeln, Statue, Telefonzelle, Schutt, verseuchter Boden; Bahnhof mit Gitterrost.

## Animation (16 Bilder, 170 ms)
Boss-Kreis, Teleporter, Giftwasser (Lichtnetz, Blasen), rote Lichter (Warnleuchten, Funkmasten, Funkturm,
Festungstor, Panzertüren, Strommast, Generator, Mech-Kopf, Kamera, Schaltkasten), Reaktoren, Laternen, Kristalle,
Konsolen, Funken am Drachen-Wrack, Rauch aus Schornsteinen, Ofenfeuer, Gras.

## Dateien
- `Spiral_Mountain_Machine_City_v1.0.png` – Standbild, `Spiral_Mountain_Machine_City_v1.0_discord.gif` – Animation.
- `kollision/` – Kollisionsraster (`kollision.json`, `.txt`, `ebene2_kollision.png`, `kollision_overlay.png`).

Erzeugt mit `tools/karte13_layout.py`, `karte13_kacheln.py`, `karte13_bauen.py`, `karte13_objekte.py`,
`regeln_v11.py karte13`, `karte13_animation.py`, `kollision.py karte13`, `tileset_export.py karte13`.

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte13_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
