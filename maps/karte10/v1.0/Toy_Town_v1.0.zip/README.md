# Karte 10 – Toy Town v1.0

90 × 75 Kacheln à 16 px (1440 × 1200), Vorlage `assets/vorlagen/karte10_vorlage.png`.
Eine Spielzeugstadt mit Straßen, Bahnhof und rosa Burg.

## Inhalt der Karte
- **Stadt:** Straßenraster mit rosa Gehwegen, Mittellinien, Zebrastreifen, Ampeln, Laternen, Hydranten; acht
  Spielzeughäuser (Doppelhaus, Kuppelhaus, rotes Haus, Burg-Wohnhaus, lila Haus, Feuerwache, Bäckerei, Spielzeugladen).
- **Bahn:** Strecke oben quer über die Karte mit Telegrafenleitung, Signalen und Schranken; Bahnhof mit Bahnsteig,
  Zug (Lok + zwei Buchstabenwagen), Wasserturm, Stellwerk, Verbindungsgleis mit Bögen, Prellböcke;
  Vorplatz mit Güterschuppen, Kohlebunker und Bushaltestelle.
- **Burg:** geschlossene Burganlage symmetrisch zur Achse: Hauptschloss als Torbau, Mauern mit Wehrgang und Zinnen,
  Rundtürme an Ecken und Seitentor, Burghof mit Soldaten, Brunnen im Rahmen, Kapelle, Stall und Spielzeugecke.
- **Park:** Spielplatz (Rutschenturm, Schaukel, Wippe, Karussell, Federwipp-Ente, Sandkasten), Teich mit Brücke,
  Uhrenplatz mit Uhrturm, Brunnenplatz mit Teleporter, Garten mit Beeten und Windmühle, Pilzhaus, Zirkuszelt.
- **Rand:** Waldrand wie Karte 01 (starr), unten über den Kartenrand hinaus.

## Animation (16 Bilder, 170 ms)
Fahnentücher, Laternen, Ampeln, Signale, Uhrzeiger, Brunnen, Lok- und Kaminrauch, Feuerwehr-Glocke, Zirkuswimpel,
Federwipp-Ente und Ballons (schaukeln), Bäume und Blumen der Stadt im Wind, Teleporter.

## Dateien
- `Toy_Town_v1.0.png` – Standbild, `Toy_Town_v1.0_discord.gif` – Animation für Discord.

Erzeugt mit `tools/karte10_layout.py`, `karte10_kacheln.py`, `karte10_bauen.py`, `karte10_objekte.py`,
`regeln_v11.py karte10`, `karte10_animation.py`, `tileset_export.py karte10`.

## Tilesets (Ordner tileset/)

Aufbau wie bei Karte 06, alles am 16x16-Raster:

- `boden_tileset.png` - jede Bodenkachel genau einmal; oben die animierten Kacheln, darunter die unbewegten.
- `boden_tileset_animiert.png` - nur die animierten Bodenkacheln, exakt am selben Platz; 16 Bilder untereinander
  (Bild n beginnt bei y = n x Hoehe des Animationsbereichs, steht in `boden_raster.json`). Einzeln in `boden_animiert_frames/`.
- `boden_raster.json` - die Karte als Raster mit dem Kachelindex je Feld; `karte10_boden.tmx` - fertige Tiled-Karte (Bodenebene).
- `objekte_tileset.png` - alle Objekte (jede Variante einmal) in ihrem eigenen Kachelblock, ohne Boden und Schatten.
- `objekte_tileset_animiert.png` - nur die animierten Objekte am exakt selben Platz, 16 Bilder untereinander;
  Einzelbilder in `animiert_frames/`.
- `objekte_tileset.json` - je Objekt: Name, Animation, Platz im Tileset, Objektblock und alle Fundstellen auf der Karte.
- Vorschauen: `vorschau_boden.png`, `vorschau_raster.png`, `vorschau_animiert.gif`, `vorschau_boden_animiert.gif`.

Bilddauer 170 ms, 16 Animationsbilder.
